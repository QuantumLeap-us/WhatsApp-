// 添加调试信息
console.log("Content script 已加载");

// 监听来自popup的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log("收到消息:", request);
    
    if (request.msg === 'do-scraping') {
        console.log("开始执行抓取");
        try {
            // 立即发送一个响应，表示消息已收到
            sendResponse({ status: "开始执行" });
            
            // 异步执行 DoScrape
            DoScrape().then(() => {
                console.log("抓取完成");
            }).catch((error) => {
                console.error("抓取出错:", error);
            });
            
            return true; // 保持消息通道开放
        } catch (error) {
            console.error("执行抓取时出错:", error);
            sendResponse({ error: error.message });
            return false;
        }
    }
    return false;
});

// 确保 content script 已经注入
console.log("Content script 注入检查点");

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// 等待元素出现
async function waitForElement(selector, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const element = document.querySelector(selector);
        if (element) {
            return element;
        }
        await sleep(100);
    }
    return null;
}

// 获取成员数量
function getMemberCount() {
    try {
        // 尝试不同的选择器来获取成员数量
        const selectors = [
            'div[data-testid="group-info-participants-section"] span',
            'div[data-testid="chat-info-drawer"] span',
            'div[role="application"] span'
        ];
        
        for (const selector of selectors) {
            const el = document.querySelector(selector);
            if (el) {
                const text = el.textContent;
                const match = text.match(/\d+/);
                if (match) {
                    return parseInt(match[0]);
                }
            }
        }
    } catch (e) {
        console.error('获取成员数量时出错:', e);
    }
    return 0;
}

async function extractPhoneNumbers() {
    const numbers = new Set();
    
    // 更新选择器以匹配新的DOM结构
    const selectors = [
        'span[dir="auto"][title*="+"]',
        'span[class*="x1iyjqo2"][title*="+"]',
        'span[class*="x10wlt62"][title*="+"]',
        'span[class*="_ao3e"][title*="+"]',
        'span[style*="min-height: 0px"][title*="+"]'
    ];

    for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
            try {
                const text = (el.getAttribute('title') || el.textContent || '').trim();
                if (!text) return;
                
                // 提取号码，支持多种格式
                const number = text.replace(/[\s\-\(\)]/g, '');
                if (number.match(/^[+]?\d{10,}$/)) {
                    numbers.add(number);
                    console.log("找到号码:", number); // 添加调试日志
                }
            } catch (e) {
                console.error('处理元素时出错:', e);
            }
        });
    }
    
    return numbers;
}

async function DoScrape() {
    console.log("开始抓取");
    
    // 创建通知元素
    let notifer_el = document.createElement("div");
    notifer_el.style.zIndex = 999999;
    notifer_el.style.backgroundColor = "#006e2b";
    notifer_el.style.color = "#ffffff";
    notifer_el.style.position = "fixed";
    notifer_el.style.left = "15px";
    notifer_el.style.top = "15px";
    notifer_el.style.width = "300px";
    notifer_el.style.fontSize = "14px";
    notifer_el.style.padding = "7px 10px 8px 10px";
    notifer_el.style.border = "3px solid #ffd000";
    notifer_el.style.borderRadius = "6px";
    notifer_el.style.lineHeight = "20px";
    notifer_el.style.boxShadow = "0 0 9px #3f3f3f42";
    
    // 添加版权信息的样式
    const copyrightStyle = "font-size: 12px; opacity: 0.8; margin-top: 5px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 5px;";
    
    notifer_el.innerHTML = `WhatsApp 群组号码抓取  </br> 🔔正在启动...</br><div style="${copyrightStyle}">TG: @Error404Hero</div>`;
    document.body.insertBefore(notifer_el, document.body.firstChild);

    let all_numbers = new Set();
    let noNewNumbersCount = 0;
    let totalScrollAttempts = 0;
    const MAX_SCROLL_ATTEMPTS = 50;

    try {
        // 声明滚动容器变量
        let scrollContainer = null;
        console.log("开始查找滚动容器...");
        
        // 首先等待对话框出现
        const dialog = await waitForElement('div[role="dialog"]');
        if (!dialog) {
            throw new Error("未找到群组对话框，请确保已打开群组信息！");
        }
        console.log("找到对话框");

        // 直接查找可能的滚动容器
        const possibleSelectors = [
            'div[data-testid="contact-list-wrapper"]',
            'div[data-testid="group-info-participants-section"]',
            'div[role="dialog"] div[tabindex="0"]',
            'div[role="dialog"] div[data-tab="2"]',
            'div[role="dialog"] div[data-tab="1"]'
        ];

        // 遍历所有可能的选择器
        for (const selector of possibleSelectors) {
            const element = dialog.querySelector(selector);
            if (element) {
                // 检查元素或其父元素是否可滚动
                let current = element;
                while (current && current !== dialog) {
                    const style = window.getComputedStyle(current);
                    if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
                        scrollContainer = current;
                        console.log("找到滚动容器:", selector);
                        break;
                    }
                    current = current.parentElement;
                }
                if (scrollContainer) break;
            }
        }

        // 如果还没找到，尝试查找所有可滚动的div
        if (!scrollContainer) {
            console.log("尝试查找任何可滚动的div...");
            const allDivs = dialog.querySelectorAll('div');
            for (const div of allDivs) {
                const style = window.getComputedStyle(div);
                if ((style.overflowY === 'auto' || style.overflowY === 'scroll') &&
                    div.scrollHeight > div.clientHeight) {
                    scrollContainer = div;
                    console.log("找到可滚动div");
                    break;
                }
            }
        }

        if (!scrollContainer) {
            throw new Error("未找到成员列表的滚动容器，请确保群组成员列表已完全展开！");
        }

        console.log("成功找到滚动容器");
        
        // 确保滚动容器中有成员列表项
        const hasMembers = scrollContainer.querySelector('div[style*="height: 72px"]');
        if (!hasMembers) {
            throw new Error("滚动容器中未找到成员列表项，请确保列表已加载！");
        }

        // 先滚动到顶部
        scrollContainer.scrollTop = 0;
        await sleep(1000);

        // 获取总成员数
        const expectedCount = getMemberCount();
        console.log("预期成员数量:", expectedCount);

        let lastScrollTop = 0;
        while (totalScrollAttempts < MAX_SCROLL_ATTEMPTS) {
            const previousSize = all_numbers.size;
            
            // 获取当前可见的号码
            const numbers = await extractPhoneNumbers();
            numbers.forEach(number => all_numbers.add(number));
            
            // 更新通知
            notifer_el.innerHTML = `WhatsApp 群组号码抓取  </br> 已找到 ${all_numbers.size} 个号码</br><div style="${copyrightStyle}">TG: @Error404Hero</div>`;
            console.log("当前找到号码数量:", all_numbers.size);
            
            // 检查是否有新号码
            if (all_numbers.size === previousSize) {
                noNewNumbersCount++;
                if (noNewNumbersCount >= 3) {
                    // 尝试更大的滚动步长
                    scrollContainer.scrollTop += 1000;
                    await sleep(1000);
                    
                    if (scrollContainer.scrollTop === lastScrollTop) {
                        console.log("已到达列表底部");
                        break;
                    }
                }
            } else {
                noNewNumbersCount = 0;
            }
            
            // 更新滚动逻辑
            lastScrollTop = scrollContainer.scrollTop;
            
            // 使用简单的scrollTop方式
            scrollContainer.scrollTop += 300; // 使用更小的滚动步长
            
            // 等待滚动完成
            await sleep(500);
            
            // 检查是否真的滚动了
            if (scrollContainer.scrollTop === lastScrollTop) {
                console.log("检测到滚动停止");
                noNewNumbersCount++;
                if (noNewNumbersCount >= 2) {
                    console.log("确认到达列表底部");
                    break;
                }
            } else {
                noNewNumbersCount = 0;
            }
            
            totalScrollAttempts++;
        }

        console.log(`抓取完成，共找到 ${all_numbers.size} 个号码`);
        if (expectedCount > 0 && all_numbers.size < expectedCount) {
            console.log(`警告：预期 ${expectedCount} 个成员，但只找到 ${all_numbers.size} 个号码`);
        }
        
        notifer_el.innerHTML = `WhatsApp 群组号码抓取  </br> ✅完成！共找到 ${all_numbers.size} 个号码</br><div style="${copyrightStyle}">TG: @Error404Hero</div>`;

        if (all_numbers.size === 0) {
            throw new Error("未能找到任何号码，请确保群组成员列表已打开并可见");
        }

        // 保存文件
        try {
            // 使用固定的文件名
            const fn = "group_name.txt";
            
            // 将Set转换为字符串，每行一个号码
            const numbersText = Array.from(all_numbers).join('\n');
            const uri = "data:text/plain;charset=utf-8," + encodeURIComponent(numbersText);
            
            let ea = document.createElement("a");
            ea.href = uri;
            ea.download = fn;
            document.body.appendChild(ea);
            ea.click();
            document.body.removeChild(ea);
        } catch (exportError) {
            console.error("保存文件时出错:", exportError);
            // 使用相同的固定文件名作为备用
            const numbersText = Array.from(all_numbers).join('\n');
            const uri = "data:text/plain;charset=utf-8," + encodeURIComponent(numbersText);
            let ea = document.createElement("a");
            ea.href = uri;
            ea.download = "group_name.txt";
            document.body.appendChild(ea);
            ea.click();
            document.body.removeChild(ea);
        }

    } catch (e) {
        console.error("抓取过程出错:", e);
        notifer_el.style.backgroundColor = "#e74c3c";
        notifer_el.innerHTML = `WhatsApp 群组号码抓取  </br> ❌错误: ${e.message}</br><div style="${copyrightStyle}">TG: @Error404Hero</div>`;
    }

    // 延迟移除通知
    await sleep(2000);
    try {
    document.body.removeChild(notifer_el);
    } catch (error) {
        console.error("移除通知元素时出错:", error);
    }
}

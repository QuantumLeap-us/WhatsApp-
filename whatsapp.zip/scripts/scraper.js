// 滚动到指定元素
function scrollIntoView(element) {
    element.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'start'
    });
}

// 获取所有成员元素
function getAllMemberElements() {
    return document.querySelectorAll('div[role="row"]');
}

// 获取成员数量
function getMemberCount() {
    const countElement = document.querySelector('div[role="application"] span');
    if (countElement) {
        const text = countElement.textContent;
        const match = text.match(/\d+/);
        return match ? parseInt(match[0]) : 0;
    }
    return 0;
}

// 检查元素是否在视图中
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// 从元素中提取电话号码
function extractNumberFromElement(element) {
    try {
        const titleSpan = element.querySelector('span[title]');
        const textSpan = element.querySelector('span[dir="auto"]');
        
        let number = '';
        if (titleSpan && titleSpan.getAttribute('title')) {
            number = titleSpan.getAttribute('title');
        } else if (textSpan) {
            number = textSpan.textContent;
        }
        
        if (number) {
            number = number.replace(/[\s\-\(\)]/g, '');
            if (number.match(/^[+]?\d{10,}$/)) {
                return number;
            }
        }
    } catch (e) {
        console.error('提取号码时出错:', e);
    }
    return null;
}

// 等待元素加载
async function waitForElement(selector, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const element = document.querySelector(selector);
        if (element) {
            return element;
        }
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    return null;
}

// 检查是否到达底部
function isAtBottom(container) {
    return container.scrollHeight - container.scrollTop === container.clientHeight;
}

// 导出函数
window.WhatsAppScraper = {
    scrollIntoView,
    getAllMemberElements,
    getMemberCount,
    isInViewport,
    extractNumberFromElement,
    waitForElement,
    isAtBottom
}; 
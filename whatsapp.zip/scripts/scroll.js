// 处理滚动和成员加载
async function scrollAndLoad() {
    return new Promise((resolve) => {
        let lastScrollHeight = 0;
        const interval = setInterval(() => {
            const scrollableElement = document.querySelector('[data-testid="contact-list-wrapper"]');
            if (!scrollableElement) return;

            const currentScrollHeight = scrollableElement.scrollHeight;
            scrollableElement.scrollTop = currentScrollHeight;

            if (lastScrollHeight === currentScrollHeight) {
                clearInterval(interval);
                resolve();
            }
            lastScrollHeight = currentScrollHeight;
        }, 100);
    });
}

// 获取所有成员
async function getAllMembers() {
    const members = new Set();
    const rows = document.querySelectorAll('div[role="row"]');
    
    for (const row of rows) {
        try {
            const cell = row.querySelector('div[role="gridcell"]:nth-child(2)');
            if (!cell) continue;

            const titleElement = cell.querySelector('span[title]');
            if (!titleElement) continue;

            const title = titleElement.getAttribute('title');
            if (!title) continue;

            // 清理并验证号码
            const number = title.replace(/[\s\-\(\)]/g, '');
            if (number.match(/^[+]?\d{10,}$/)) {
                members.add(number);
            }
        } catch (error) {
            console.error('处理成员时出错:', error);
        }
    }
    
    return members;
}

// 导出函数
window.WhatsAppScraper = {
    scrollAndLoad,
    getAllMembers
}; 